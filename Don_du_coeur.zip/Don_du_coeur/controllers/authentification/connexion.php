<?php 
    require_once("../../models/model_general.php");

    require("../../models/authentification/connexion.php");
    session_start();
    extract($_POST);//email,passe
     $password = md5($password);
    //  $utilisateur = checker($email);
    
    if(!empty($utilisateur))
    {
        // Créer la session
        $_SESSION['utilisateur'] = $utilisateur;
        header('location:../../views/utilisateurs/profils.php'); 
        die();
    }
    else
    {
        header("location:../../views/autentification/connexion.php?cn=erreur");
        die();  
          
    }
    var_dump();
?>