
<?php
    require_once("../../models/model_general.php");
   
    require_once("../../modules/module.php");

    require_once("../../models/utilisateurs/modifier_profil.php");
     session_start();
     extract($_POST);

    $utilisateur_id = $_SESSION['utilisateur']['id']; 

    $dossier = "../../assets/images/profil";

    $upload = uploader_image_resized('chemin',30000000,2000,2000,400,400,$dossier);

    // if($_SESSION['utilisateur']['image_profil'] != "inconnu.jpg")
    
    //  {
    //      unlink($dossier."/".$_SESSION['utilisateur']['image_profil'];
    //  }

    update_profil_image($upload,$_SESSION['utilisateur']['id'],2);

    $_SESSION['utilisateur']['image_profil'] = $upload;


   //modification($ville,$telephone,$pays,$sexe,$date_naissance,$site_internet,$biographie,$utilisateur_id);
     header('location:../../views/utilisateurs/profil.php');
?>