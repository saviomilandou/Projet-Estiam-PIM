-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : lun. 27 juin 2022 à 10:43
-- Version du serveur : 5.7.33
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `doncoeur`
--

-- --------------------------------------------------------

--
-- Structure de la table `donnation`
--

CREATE TABLE `donnation` (
  `id` int(11) NOT NULL,
  `titre` varchar(100) NOT NULL,
  `don_propose` int(11) NOT NULL,
  `description` text NOT NULL,
  `beneficiere_id` int(11) NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  `date_envoie` datetime NOT NULL,
  `periode_voulu` varchar(10) NOT NULL,
  `date_recuperation` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `profil_enregistrer`
--

CREATE TABLE `profil_enregistrer` (
  `id` int(11) NOT NULL,
  `donnateure_id` int(11) NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  `date_enregistrement` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `raisonsociale` varchar(50) DEFAULT NULL,
  `ville` varchar(50) NOT NULL,
  `code_postal` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telephone` varchar(45) NOT NULL,
  `secteur_activite` varchar(45) DEFAULT NULL,
  `statu` varchar(15) NOT NULL,
  `sexe` varchar(50) DEFAULT NULL,
  `image_profil` varchar(255) DEFAULT NULL,
  `date_enregistrement` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `prenom`, `raisonsociale`, `ville`, `code_postal`, `email`, `password`, `telephone`, `secteur_activite`, `statu`, `sexe`, `image_profil`, `date_enregistrement`) VALUES
(6, 'Okoumou', 'Dassoah', '', 'Casablanca', '7895', 'dassoah@gmail.com', '12345', '78965234', NULL, 'particulier', 'home', 'inconnu.png', '2022-05-25 02:03:32'),
(9, 'Benzema', 'Karim', '', 'Madrid', '7500', 'karim@gmail.com', '202cb962ac59075b964b07152d234b70', '06785942', NULL, 'particulier', 'homme', 'inconnu.png', '2022-05-26 10:40:32'),
(10, NULL, NULL, 'Secours populaire', 'Paris', '75000', 'secours@gmail.com', '202cb962ac59075b964b07152d234b70', '786954123', 'social', 'association', NULL, 'inconnu.png', '2022-05-26 10:45:47');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `donnation`
--
ALTER TABLE `donnation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_beneficiere_id_donnation` (`beneficiere_id`),
  ADD KEY `fk_utilisateur_id_donnation` (`utilisateur_id`);

--
-- Index pour la table `profil_enregistrer`
--
ALTER TABLE `profil_enregistrer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_donnateure_id_profil_enregistrer` (`donnateure_id`),
  ADD KEY `fk_utilisateur_id_profil_enregistrer` (`utilisateur_id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `donnation`
--
ALTER TABLE `donnation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `profil_enregistrer`
--
ALTER TABLE `profil_enregistrer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `donnation`
--
ALTER TABLE `donnation`
  ADD CONSTRAINT `fk_beneficiere_id_donnation` FOREIGN KEY (`beneficiere_id`) REFERENCES `utilisateurs` (`id`),
  ADD CONSTRAINT `fk_utilisateur_id_donnation` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`);

--
-- Contraintes pour la table `profil_enregistrer`
--
ALTER TABLE `profil_enregistrer`
  ADD CONSTRAINT `fk_donnateure_id_profil_enregistrer` FOREIGN KEY (`donnateure_id`) REFERENCES `utilisateurs` (`id`),
  ADD CONSTRAINT `fk_utilisateur_id_profil_enregistrer` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
