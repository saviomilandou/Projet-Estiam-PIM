 <?php
  header('location:home');
  // echo "Bonjour";
?> 