<?php

    function inscription($nom,$prenom,$email,$objet,$message ){
            
        $connexion = connecter_db();

        // Inscription de membres
        $req = $connexion->prepare("INSERT INTO contact(nom,prenom,email,objet,message,date_envoi) values(?,?,?,?,?,now())");
        $req->execute([$nom,$prenom,$email,$objet,$message]);
    }
?>  