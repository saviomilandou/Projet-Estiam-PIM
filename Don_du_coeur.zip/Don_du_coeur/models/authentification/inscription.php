<?php
    
    function inscription($nom,$prenom,$raisonsociale,$ville,$code_postal,$email,$password,$telephone,$secteur_activite = null,$statu,$sexe,$image_profil = "inconnu.png"){

        $connexion = connecter_db();

        // Inscription de l'utilisateur
        $req = $connexion->prepare("INSERT INTO utilisateurs(nom,prenom,raisonsociale,ville,code_postal,email,password,telephone,secteur_activite,statu,sexe,image_profil,date_enregistrement) values(?,?,?,?,?,?,?,?,?,?,?,?,now())");
        $req->execute([$nom,$prenom,$raisonsociale,$ville,$code_postal,$email,$password,$telephone,$secteur_activite,$statu,$sexe,$image_profil]);
    }