<?php

function ajouter($titre,$don_propose,$description,$donnateur_id,$utilisateur_id,$date_envoi_don,$ville,$periode_voulu){

    $connexion = connecter_db();

    // demande prestation (anyDesk==> logiciel de contôte machine a distance )
    
    $req = $connexion->prepare("INSERT INTO donnateur(titre,don_propose,description,donnateur_id,utilisateur_id,date_envoi_don,ville,periode_voulu) values(?,?,?,?,?,?,?,?,now())");
    $req->execute([$titre,$don_propose,$description,$donnateur_id,$utilisateur_id,$date_envoi_don,$ville,$periode_voulu]);

}