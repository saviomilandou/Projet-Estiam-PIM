<?php 
function modification($id,$sexe,$ville,$telephone,,$date_naissance,$description,$autre_information){

        $link=connecter_db();
        $rp=$link->prepare("UPDATE utilisateurs(id=?,sexe=?,ville=?,telephone=?,date_naissance=?,description=?,autre_information=? WHERE id='?' ");
        
        $rp->execute([$id,$sexe,$ville,$telephone,,$date_naissance,$description,$autre_information]);  
}
?>