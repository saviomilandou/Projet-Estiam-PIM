
<?php
include("../header.php");

?>
<!-- ======================================carousel================================================= -->
        
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img class="d-block w-100" src="../../assets/images/slider/01.jpg" role="listbox">

                        <div class="carousel-caption text-center ">
                                <h1 class="animated fadeInDown">Welcome to Don du coeur</h1>
                                <p class="animated fadeInUp text-dark"><b>L’idée du projet [Don DU Cœur] est née du désir de fournir à une partie donnée de la population française un outil, un moyen de bénéficier ou pour d’autres de procurer une aide, un soin ou même un service portant sur le bienêtre de la personne..</b></p>
                                <button class="btn btn-defualt animated zoomIn">Voir plus </button>
                        </div>
                      
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="../../assets/images/slider/00.png" alt="..." role="listbox">
                    <div class="carousel-caption text-center">
                            <h1 class="animated fadeInDown">Bienvenue sur Don du coeur </h1>
                            <p class="animated fadeInUp text-dark"><b>L’idée du projet [Don DU Cœur] est née du désir de fournir à une partie donnée de la population française un outil, un moyen de bénéficier ou pour d’autres de procurer une aide, un soin ou même un service portant sur le bienêtre de la personne.</b></p>
                            <button class="btn btn-defualt animated zoomIn">Voir plus</button>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="../../assets/images/slider/03.jpg" alt="..." role="listbox">
                    <div class="carousel-caption text-center">
                            <h1 class="animated zoomIn">Web Design </h1>
                            <p class="animated zoomIn">Aliquam quis unde nobis aspernatur,<br/> perferendis sed explicabo obcaecati provident repudiandae.</p>
                            <button class="btn btn-defualt animated zoomIn">Voir plus </button>
                    </div>
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                  <span class="carousel-control" aria-hidden="true"><i class="fas fa-long-arrow-alt-left"></i></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                  <span class="carousel-control" aria-hidden="true"><i class="fas fa-long-arrow-alt-right"></i></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>


              
    </header>

    </body>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</html>