<?php  
    //  require_once("../models/model_general.php");

    //  compter_visiter($_SERVER['REMOTE_ADDR'],"index");
     
    
  ?>

<!doctype html>
<html class="no-js" lang="en">

<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Don du coeur  ||Home  </title>
        <meta name="description" content="L’idée du projet [Don DU Cœur] est née du désir de fournir à une partie donnée de la population française un outil, un moyen de bénéficier ou pour d’autres de procurer une aide, un soin ou même un service portant sur le bienêtre de la personne.">
        <meta name="viewport" content="L’idée du projet [Don DU Cœur] est née du désir de fournir à une partie donnée de la population française un outil, un moyen de bénéficier ou pour d’autres de procurer une aide, un soin ou même un service portant sur le bienêtre de la personne.">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../../assets/images/image/icon.PNG">
        
    <!-- CSS 
    ========================= -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">


    <!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->

<link rel="stylesheet" href="../../assets/css/stylescoeur.css">
<link rel="stylesheet" href="css/animate.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
</head>



<!------ Include the above in your HEAD tag ---------->




    <header>
       <!-- ======================================Navigation Bar================================================= -->
        <nav class="navbar navbar-expand-lg navStyle">
            <a class="brand-navbar" href="#"><img src="../../assets/images/image/icon.PNG" alt="Responsive image" height="60px"></a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#mainMenu">
                <span><i class="fas fa-align-right iconStyle"></i></span>
            </button>
            <div class="collapse navbar-collapse" id="mainMenu">
                <ul class="navbar-nav ml-auto navList">
                    <li class="nav-item active"><a href="#" class="nav-link"><i class="fas fa-home"></i>HOME<span class="sr-only">(current)</span></a></li>
                    <li class="nav-item">
                        <a href="autentification/profil.php" class="nav-link"><i class="fas fa-cogs"></i>Services</a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="../utilisateurs/profils.php" class="nav-link"><i class="fas fa-users"></i>profil</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.html" class="nav-link"><i class="fas fa-phone"></i>Contact</a>
                    </li>
                    <li class="nav-item">
                        <a href="../utilisateurs/profils.php" class="nav-link"><i class="fas fa-heart"></i>Faire un don </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="../autentification/inscription.php" class="nav-link"><i class="fas fa-arrow-right"></i>Inscrition</a>
                    </li>
                    <li class="nav-item">
                        <a href="../autentification/connexion.php" class="nav-link"><i class="fas fa-unlock"> </i>Connexion</a>
                    </li>
                </ul>
            </div>
        </nav>
        
    </header>

</html>

