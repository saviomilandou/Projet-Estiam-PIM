<?php 
    if(isset($_SESSION['utilisateur'])){
        // require_once("../header_profil.php");
    }
    else
    {
         include_once("../header.php");
    }
?>

<br><br>

<?php  if(isset($_GET['cn'])){ ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
 </head>
 <body>
   
 <div><h5 class="text-danger text-center mb-4"> Mot de passe incorrects</h5>
</div>
<?php } ?> 

<form action="../../controllers/authentification/connexion.php" method ="post"> 

<section class="login-block">
    <div class="container">
	<div class="row">
		<div class="col-md-4 login-sec">
		    <h2 class="text-center">Connectez-vous maintenant</h2>
		    <form class="login-form">
  <div class="form-group">
    <label for="email" class="text-uppercase">Nom d'utilisateur</label>
    <input type="email"  name="email" id="email" class="form-control" placeholder="">
    
  </div>
  <div class="form-group">
    <label for="password" class="text-uppercase">Mot de passe </label>
    <input type="password" name="password"  id="password"  class="form-control" id=""placeholder="" required> 
  </div>
  
  
    <div class="form-check">
    <label class="form-check-label">
      <input type="checkbox" class="form-check-input">
      <small>J'accepete les condition d'utilisations</small>
    </label><br><br>
    <button type="submit" class="btn btn-login float-right">Connexion</button>
  </div>
  <div class="copy-text"><a href="">Mot de passe oublié <i class="fa fa-heart"></i></a></div>
</form>
		</div>
		<div class="col-md-8 banner-sec">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  </ol>
            <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="https://static.pexels.com/photos/33972/pexels-photo.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            <h2 class="text-warning">Don du coeur </h2>
            <p>L’idée du projet [Don DU Coeur] est née du désir de fournir à une partie donnée de la population 
              française un outil, un moyen de bénéficier ou pour d’autres de procurer une aide, un soin ou même
               un service portant sur le bienêtre de la personne.</p>
        </div>	
  </div>
    </div>
    <!-- <div class="carousel-item">
      <img class="d-block img-fluid" src="../../assets/images/image/icon002..PNG" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            <h2>This is Heaven</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
        </div>	
    </div> -->

    </div>
    <!-- <div class="carousel-item">
      <img class="d-block img-fluid" src="../../assets/images/image/icon01..jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            <h2>This is Heaven</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
        </div>	
      </div>
    </div> -->

  </div>	   
		    
		</div>
	</div>
</div>

</section>
<br><br><br><br>


 </body>
 

 </html>

