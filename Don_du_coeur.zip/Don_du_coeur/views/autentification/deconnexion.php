<?php 
    session_start();
    $_SESSION['utilisateur'] = [];
    session_destroy();
    header('location:../home/accueil.php');