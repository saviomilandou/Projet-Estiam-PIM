<?php 
    session_start();

   //  https://bootsnipp.com/snippets/dlZAN


    if(isset($_SESSION['utilisateur'])){
        require_once("../header_profil.php");
    }
    else
    {
        require_once("../header.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container register">
  <h1 class="text-center mt-4">Inscription</h1>

<h5 class="text-center mt-4 text-white">D'éjà Inscrit ? <a href="connexion.php">Connectez-vous</a></h5>

                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="../../assets/images/image/icon002.PNG" alt=""/>
                        <h3>Don du Coeur </h3>
                     
                       
                    </div>
                    <div class="col-md-9 register-right">
                        <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#home"aria-controls="home" >Particulier</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#profile" aria-controls="profile">Associaion</a>
                            </li>
                        </ul>


                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="home">
                                <h3 class="register-heading">S'inscrire comme particulier  </h3>

                                <form action="../../controllers/authentification/inscription.php?t=utilisateurs&       statu=particulier" method="post"  >

                                   <div class="row register-form">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                             <input type="text" name="nom"  id="nom"  class="form-control" id="nom"placeholder="Nom*" required>               
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="text" name="prenom"  id="prenom"  class="form-control" id="prenom"placeholder="Prénom*" required>               
                                        </div>

                                        <div class="form-group">
                                            <input type="text" name="ville"  id="ville"  class="form-control"  id="ville"placeholder="Ville*" required>               
                                        </div>

                                        <div class="form-group">
                                           <input type="text" name="code postal"  id="code postal"  class="form-control"   id="code postal"placeholder="Code postal*" required>               
                                        </div>
                                        
                                        <div class="form-group">
                                            <div class="maxl">
                                                <label class="radio inline"> 
                                                    <input type="radio" name="sexe" value="homme" checked>
                                                    <span> Homme </span> 
                                                </label>
                                                <label class="radio inline"> 
                                                    <input type="radio" name="sexe" value="femme">
                                                    <span>Femme </span> 
                                                </label>
                                            </div>

                                        </div>

                                     </div>

                                      <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" name="email"  id="email"  class="form-control" id="email"placeholder="Email*" required>               
                                        </div>

                                        <div class="form-group">
                                            <input type="password" name="password"  id="password"  class="form-control" id=""placeholder="Mot de passe *" required>               
                                        </div>

                                        <div class="form-group">
                                            <input type="nuber" name="telephone"  id="telephone"  class="form-control" id="telephone"placeholder="télephone*" required>               
                                        </div>

                                        <div class="form-group">
                                            <select class="form-control">
                                                <option class="hidden"  selected disabled>votre statu </option>
                                                <option>Votre statu</option>
                                                <option>Je suis un particulier</option>
                                            </select>
                                        </div>
                                      
                                        <input type="submit" class="btnRegister"  value="S'incrire"/>
                                      </div>
                                   </div>
                                </form>
                            </div>

                            <div class="tab-pane fade show" id="profile">
                                <h3  class="register-heading">S'inscrire comme Association / Entreprise </h3>
                                <div class="row register-form">

                                <form action="../../controllers/authentification/inscription.php?t=utilisateurs&      statu=association" method="post">


                                    <div class="row register-form">
                                      <div class="col-md-6">

                                        <div class="form-group">
                                          <input type="text" name="raisonsociale"  id="raisonsociale"class="form-control" id="raisonsociale"placeholder="Raisonsociale*" required>  
                                        </div>

                                        <div class="form-group">
                                            <input type="text" name="ville"id="ville"class="form-control" id="ville"placeholder="Ville*" required> 
                                        </div>
                                      
                                        <div class="form-group">
                                         <input type="text" name="code postal"id="code postal" class="form-control" id="code postal"placeholder="Code postal*" required>               
                                        </div>
                                      
                                       

                                        <div class="form-group">
                                          <input type="email" name="email"id="email"class="form-control" id="email"placeholder="Email*" required>               
                                        </div>

                                        </div>

                                       <div class="col-md-6">
                                           <div class="form-group">
                                             <input type="password" name="password"id="password"  class="form-control" id="email"placeholder="Mot de passe *" required>               
                                          </div>

                                          <div class="form-group">
                                             <input type="nuber" name="telephone"  id="telephone"  class="form-control" id="telephone"placeholder="télephone*" required>               
                                          </div>

                                      
                                          <div class="form-group">
                                             <input type="text" name="secteur_activite"  id="secteur_activite"  class="form-control" id="secteur_activité"placeholder=" secteur_activite*" required>               
                                         </div>


                                         <div class="form-group">
                                            <select class="form-control">
                                                <option class="hidden"  selected disabled>votre statu </option>
                                            
                                                <option>Une association</option>
                                                <option>Une entreprise</option>
                                            </select>
                                         </div>
                                      
                                            <input type="submit" class="btnRegister"  value="S'incrire"/>
                                       </div>
                                       </div>
                                       
                                    </div>
                               </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <br><br><br><br>
</body>
</html>
<!-- 

            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
            <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>