<?php  
     require_once("../../models/model_general.php");

     compter_visiter($_SERVER['REMOTE_ADDR'],"contact");
     
  
  ?>
 <!-- Header -->
 <?php include("../header.php"); ?>
    <!-- Header -->   


    
    <div class="breadcrumb-area bg-info" data-bgimage="" data-black-overlay="4"> <img src="assets/images/slider/breadcrumb-bg-801.jpg" height="100%" alt=""> 
        
        <div class="container">
            <div class="in-breadcrumb ">
                <div class="row">
                    <div class="col">
                        <h3>Contactez-Nous </h3>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="home">Home</a></li>
                            <li class="breadcrumb-item active">Contact</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Breadcrumb -->
    
    
    
    <!-- Page Conttent -->
    <main class="page-content section-ptb">
       <div class="container">
            <div class="row">
                <div class="col-lg-7 col-sm-12">
                    <div class="contact-form">
                        <div class="contact-form-info">
                            <div class="contact-title">
                                <h3 class="text-info">Laissez nous un Message </h3>

                            </div>
                            <form action="tcontact" method="post"  >

                               <div class="contact-page-form">
                                   <div class="contact-input">
                                        <div class="contact-inner">
                                            <input data-parsley-minlength="3" name="nom" type="text" placeholder="Votre Nom  *" id="Votre Nom " required>
                                        </div>
                                        <div class="contact-inner">
                                            <input data-parsley-minlength="4" name="prenom" type="text" placeholder="Votre Prenom *" id="Votre Prenom " required>
                                        </div>
                                        <div class="contact-inner">
                                            <input type="text" placeholder="Email *" id="email" name="email" required>
                                        </div>
                                        <div class="contact-inner">
                                            <input name="objet" type="text" placeholder="Objet *" id="subject" required>
                                        </div>
                                        <div class="contact-inner contact-message">
                                            <textarea name="message"  placeholder="Message *"  required></textarea>
                                        </div>
                                    </div>
                                    <div class="contact-submit-btn">
                                        <button class="submit-btn" type="submit">Envoyer votre Email</button>
                                        <p class="form-messege"></p>
                                    </div>
                               </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-sm-12">
                    <div class="contact-infor">
                        <div class="contact-title">
                            <h3 class="text-danger">Nous contacter</h3>
                        </div>
                        <div class="contact-dec">
                            <p>Entrez vos informations et votre message dans le formulaire ci-dessous nous vous répondrons dans les plus brefs délais.</p>
                        </div>
                        <div class="contact-address">
                            <ul>
                                <li><i class="fa fa-home"></i> Adress : Ville Paris, France </li>
                                <li><a href="mailto:contact@etudier-enfrance.com"target="_blank"><i class="fa fa-envelope"></i>contact@etudier-enfrance.com</a></li>
                                
                                <!-- <li><i class="fa fa-phone"></i> +33 64 14 50 286</li> -->
                            </ul>
                        </div>
                        <div class="work-hours">
                            <h6><strong>Toujours Disponible</strong></h6>
                            <p><strong>Disponible</strong>: &nbsp;7jours/7</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!--// Page Conttent -->
    
    <!-- Footer Area -->
    <?php
include("../footer.php");
?>
    <!--// Footer Area -->
    
    
</div>
<!-- Main Wrapper End -->

<!-- JS
============================================ -->

<!-- jQuery JS -->
<script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Ajax Mail -->
<script src="assets/js/ajax-mail.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>
<script src="assets/js/parsley.min.js"></script>


</body>

</html>