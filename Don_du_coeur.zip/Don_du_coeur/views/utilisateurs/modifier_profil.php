<?php 
     require_once("../../modules/module.php");
     require_once("../../models/modifier/modifier_profil.php");


    session_start();
    
    if(empty($_SESSION['utilisateur']))
    {
      include("../header.php");
    }
    else
    {
      include("../header_profil.php");
    }
  

      $pays = all("pays");
  ?>
  
<div class="container">

  <br><br>
    <div class="row">
    <form action="../../controllers/modifier/modifier_profil.php" method="post" enctype="multipart/form-data" >
           <div class="col-4 px-md-4  ">
              <div class="border border-secondary">
                 <img src="../../assets/images/profil/<?= $_SESSION['utilisateur']['image_profil']; ?>" width ="235px" alt="">  <br>
                  <input class="browse-input" type="file" required name="chemin" id="chemin"/>   
               </div>
                 <br>
            
                <button class="btn btn-info">Enregistré</button></div>   
             
        </form>


            <div class="col-8 px-md-5 border border-white ">
        
         <div class="p-2  bg-secondary"><h5 class="text-white text-center">Indentités</h5></div>
         <form action="../../controllers/modifier/modifier_profil.php" method="post"  >
      
                  <div class="row mt-4">
                    <div class="col">
       
                      <select id="inputState" id="pays"  name="pays"  class="form-control"> 
                     
                     <option selected>Pays</option>
                     <?php
                     foreach($pays as $for)  {
                     ?>
                     <option value="<?=$for["id"];?>">  <?=$for["name"];?></option>
                    
                     <?php } ?>

                    </select> 
                   </div>
                   
                    <div class="col">
                      <select id="inputState" name="sexe"   id="sexe"  class="form-control" placeholder="Sexe">
                             <option selected>Complété votre sexe</option>
                   
                         <option value="Masculin">Masculin</option>
                         <option value="Feminin">Feminin</option>
                     
                       </select>

                    </div>

                        </div>
                           <br>
                         <div class="row mt-5">

                   <div class="col">
                      <input type="ville" class="form-control" name="ville"placeholder="Ville ">
                   </div>

                       <div class="col">
                           <input type="text" class="form-control"  name="telephone" placeholder="Télephone">
                       </div>

                       
                          </div>

                          <br>
                          <div class="row mt-5">
                   <div class="col">
                        <input type="text" class="form-control" name="site_internet"placeholder="Site internet">
                   </div>


                   <div class="col">
                      <input type="date" class="form-control" name="date_naissance"   id="date_naissance" placeholder="Date de Naissance">
                   </div>
                    
                   <br><br><br>

              <div class="form-group">  

                <div class="input-group form-group">
                  <textarea id="biographie" name="biographie" class="span6 text-center" placeholder="Votre Biographie"cols="90"  rows="8"></textarea>
                </div>

              </div>


                    <div class="col">
                    
                    <select value="Bonjour" class="select2 form-control select2-multiple" name="genres[]" multiple="multiple" multiple data-placeholder="Genre du film">


                       <option selected>Complété vos competences</option>
                        <?php
                        foreach($categorie as $for)  {
                        ?>
                         <option value="<?=$for["id"];?>" ><?=$for["nom"];?></option>
                    
                         <?php } ?> 

                       </select>

                    </div>

                        </div>


                        <div class="text-center mt-5">
                          <button class="btn btn-danger btn-lg  ">Enregistré</button>
                          
                        </div>
         </form>
         

             </div>


    </div>

    <br><br><br><br>

</div>

<?php require_once("../footer.php"); ?>








