<H1>Bienvenue sur le profil utilsateur </H1>

<?php 
    session_start();

    if(isset($_SESSION['utilisateur'])){

        require_once("../header_profil.php");
    }
    else
    {
        require_once("../header.php");
    }
    

    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
    }
    else
    {
        $id = $_SESSION['utilisateur']['id'];
    }

    $profil = findBy("utilisateurs",$id);

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="../../assets/css/stylefooter.css">
    <title>Profil</title>
</head>
<body>


<div class="container pt-5 ">

    <div class="row">

    <div class="col-md-4 img">
      <img src="../../assets/images/profil/<?= $profil['image_profil']; ?>" width ="250px" alt=""> 
    </div>

    <div class="col-md-4 details">
      <blockquote>
        <h5><?= $profil['prenom']; ?> <?=$profil['nom']; ?> <?=$profil['raisonsociale']; ?></h5>

        <!-- Récupération du pays -->
        <?php 
        $pays = findby("pays",$profil['pays']);
        ?>
        <?php ?>
        
        <h5><cite title="Source Title"><i class="fa fa-map-marker mx-1"></i><?=$profil['ville'];?> <?=$pays['name'];?></cite></h5>
      </blockquote>
      <p>
        <h5><?=$profil['email']; ?> </h5>
      <h5 class="text-primary" > Profil: <?=$profil['type']; ?></h5> 
     <h5>                     <?php
                      $cat = findBy('categories',$profil['activite_id']);
                      echo $cat['nom'];
                    ?></h5> 
      </p>
    </div>

    <div class="col-md-4 details">
     
        <?php 
        if(isset($_SESSION['utilisateur'])) {
                if($_SESSION['utilisateur']['id'] == $profil['id'])
                {
                ?> 

       <h4><a href="../projet/demande.php?profil=<?=$profil['id'] ?>"> 
        <!-- <button class="btn btn-info btn-lg btn-block">Proposer moi un Projet</button> -->
     <!-- </a>
 </h4>
 <p>Au dela d'une simple prestation, je vous propose un accampagnement personnalisé pour une bonne organisation de votre evenement</p>
  <br><br> -->

  <h4><a href="modifier_profil.php"><button class="btn btn-danger btn-lg btn-block">Modifier votre profil</button></a>
 </h4> 
            <?php 
                }
                else
                {
                    ?>
                   <h4><a href="../projet/demande.php?profil=<?=$profil['id'] ?>"> 
      


                   <button class="btn btn-info btn-lg btn-block">Proposer moi un Projet</button>
         </a>
     </h4>
     <p>Au dela d'une simple prestation, je vous propose un accampagnement personnalisé pour une bonne organisation de votre evenement</p>
      <br><br> 

     <?php
                }

            }
            else
            {
                ?>
 

        <button class="btn btn-info btn-lg btn-block">Proposer moi un Projet</button>
         </a>
     </h4>
     <p>Au dela d'une simple prestation, je vous propose un accampagnement personnalisé pour une bonne organisation de votre evenement</p>
      <br><br> 
 <?php
            }
            ?>
        <?php ?>


    </div>



           <div class="col-md-4  ">
              <br><br>
               <h3 class="title-widget text-center">Mes competences  </h3>           
             <div class="col">
             <select class="select2 form-control select2-multiple" name="genres[]" multiple="multiple" multiple data-placeholder="Genre du film">
                   
                     <option  disabled selected> Complèté vots comptetances </option>
                     <?php
                     foreach($categorie as $for)  {
                     ?>
                     <option value="<?=$for["id"];?>" ><?=$for["nom"];?></option>
                    
                     <?php } ?>

                     </select>
                     <br>

                </div>
            </div>

        
            <div class="col-md-8 ">   
        
                <div class="p-3 mb-2 bg-secondary text-white">
                
                   <h3 class=" text-center mb-4">Qui suis-je ? </h3>
                 <p>
                 <?php if($profil['biographie'] == null){ ?>

                     Biographie non compléter

                     <?php }else{?>
            <?= $profil['biographie']; ?>   

                     <?php } ?>

                </p>
                
                </div>
                </div>
            </div>
                       

    </div>
    <br><br>
     
 </div>

 <br><br>
   <h4 class="text-center mb-3 d-none">Mes Prestation en images</h4>


    <div class="row mx-auto d-none">
	    <div class="col-sm-4">
	        <div class="item"><img src="../assets/images/oo.jpg" class="img-thumbnail" ></div>
	
	    </div>
	    <div class="col-sm-4">
		    <div class="item"><img src="../assets/images/mariage.jpg" class="img-thumbnail"></div>
	    </div>
	    <div class="col-sm-4">
		    <div class="item"><img src="../assets/images/banniere.jpg" class="img-thumbnail"></div>
	    </div>
    </div>


</div>


<br><br><br><br><br><br><br><br>
<?php require_once("../footer.php"); ?>


<script>
// Material Select Initialization
$(document).ready(function() {
$('.mdb-select').materialSelect();
});
</script>